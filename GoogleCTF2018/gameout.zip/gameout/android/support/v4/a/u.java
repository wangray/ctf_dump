package android.support.v4.a;

import android.os.Bundle;
import android.support.v4.b.b;

public abstract class u {

    public interface a<D> {
        b<D> a(int i, Bundle bundle);

        void a(b<D> bVar);

        void a(b<D> bVar, D d);
    }

    public boolean a() {
        return false;
    }
}
