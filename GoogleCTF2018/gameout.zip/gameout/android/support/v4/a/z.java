package android.support.v4.a;

import android.util.AndroidRuntimeException;

final class z extends AndroidRuntimeException {
    public z(String str) {
        super(str);
    }
}
