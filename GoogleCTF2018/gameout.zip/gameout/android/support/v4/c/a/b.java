package android.support.v4.c.a;

import android.graphics.drawable.Drawable;

public interface b {
    Drawable a();

    void a(Drawable drawable);
}
