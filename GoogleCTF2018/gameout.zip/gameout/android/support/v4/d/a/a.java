package android.support.v4.d.a;

import android.view.Menu;

public interface a extends Menu {
}
