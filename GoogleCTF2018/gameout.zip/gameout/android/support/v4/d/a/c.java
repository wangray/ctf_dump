package android.support.v4.d.a;

import android.view.SubMenu;

public interface c extends a, SubMenu {
}
