package android.support.v4.h;

public interface h {
    void stopNestedScroll();
}
