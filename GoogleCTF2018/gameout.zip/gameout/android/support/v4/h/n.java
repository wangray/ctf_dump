package android.support.v4.h;

import android.view.View;

public interface n {
    v a(View view, v vVar);
}
