package android.support.v4.h;

import android.view.View;

public interface s {
    void a(View view);

    void b(View view);

    void c(View view);
}
