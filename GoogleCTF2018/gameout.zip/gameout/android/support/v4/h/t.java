package android.support.v4.h;

import android.view.View;

public class t implements s {
    public void a(View view) {
    }

    public void b(View view) {
    }

    public void c(View view) {
    }
}
