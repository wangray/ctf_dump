package android.support.v4.h;

import android.view.View;

public interface u {
    void a(View view);
}
