package android.support.v7.app;

import android.support.v7.view.b;
import android.support.v7.view.b.a;

public interface d {
    b a(a aVar);

    void a(b bVar);

    void b(b bVar);
}
