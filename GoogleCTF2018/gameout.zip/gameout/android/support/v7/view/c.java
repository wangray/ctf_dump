package android.support.v7.view;

public interface c {
    void a();

    void b();
}
