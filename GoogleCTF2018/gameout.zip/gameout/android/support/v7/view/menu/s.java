package android.support.v7.view.menu;

import android.widget.ListView;

public interface s {
    void a();

    void c();

    boolean d();

    ListView e();
}
