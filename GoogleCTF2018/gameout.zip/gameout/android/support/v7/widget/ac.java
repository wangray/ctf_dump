package android.support.v7.widget;

import android.support.v7.view.menu.o.a;
import android.view.Menu;
import android.view.Window.Callback;

public interface ac {
    void a(int i);

    void a(Menu menu, a aVar);

    boolean e();

    boolean f();

    boolean g();

    boolean h();

    boolean i();

    void j();

    void k();

    void setWindowCallback(Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
