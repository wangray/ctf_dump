package android.support.v7.widget;

import android.graphics.Rect;

public interface ag {

    public interface a {
        void a(Rect rect);
    }

    void setOnFitSystemWindowsListener(a aVar);
}
