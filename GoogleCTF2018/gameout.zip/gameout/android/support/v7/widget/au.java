package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

class au {
    public ColorStateList a;
    public Mode b;
    public boolean c;
    public boolean d;

    au() {
    }

    void a() {
        this.a = null;
        this.d = false;
        this.b = null;
        this.c = false;
    }
}
