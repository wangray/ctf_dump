package android.arch.a.a;

import java.util.HashMap;

public class a<K, V> extends b<K, V> {
    private HashMap<K, c<K, V>> a = new HashMap();

    public boolean a(K k) {
        return this.a.containsKey(k);
    }
}
