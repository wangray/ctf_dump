package android.arch.lifecycle;

public interface a {
    void a(c cVar, android.arch.lifecycle.b.a aVar);
}
