package android.arch.lifecycle;

public interface c {
    b a();
}
