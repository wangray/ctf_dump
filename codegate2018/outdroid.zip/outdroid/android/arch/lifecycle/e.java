package android.arch.lifecycle;

@Deprecated
public interface e extends c {
    d b();
}
