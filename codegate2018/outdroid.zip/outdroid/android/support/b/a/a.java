package android.support.b.a;

class a {
    static final int[] a = new int[]{16842755, 16843041, 16843093, 16843097, 16843551, 16843754, 16843771, 16843778, 16843779};
    static final int[] b = new int[]{16842755, 16843189, 16843190, 16843556, 16843557, 16843558, 16843866, 16843867};
    static final int[] c = new int[]{16842755, 16843780, 16843781, 16843782, 16843783, 16843784, 16843785, 16843786, 16843787, 16843788, 16843789, 16843979, 16843980, 16844062};
    static final int[] d = new int[]{16842755, 16843781};
    static final int[] e = new int[]{16843161};
    static final int[] f = new int[]{16842755, 16843213};
    public static final int[] g = new int[]{16843073, 16843160, 16843198, 16843199, 16843200, 16843486, 16843487, 16843488, 17891484};
    public static final int[] h = new int[]{16843490};
    public static final int[] i = new int[]{16843486, 16843487, 16843488, 16843489};
    public static final int[] j = new int[]{16842788, 16843073, 16843488, 16843992};
    public static final int[] k = new int[]{16843489, 16843781, 16843892, 16843893};
    public static final int[] l = new int[]{16843772, 16843773, 16843774, 16843775, 16843781};
}
