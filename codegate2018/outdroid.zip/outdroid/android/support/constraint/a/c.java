package android.support.constraint.a;

public class c {
    a<b> a = new b(256);
    a<g> b = new b(256);
    g[] c = new g[32];
}
