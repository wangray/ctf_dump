package android.support.design.widget;

import android.support.v4.i.b.b;
import android.support.v4.i.b.c;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;

class a {
    static final Interpolator a = new LinearInterpolator();
    static final Interpolator b = new b();
    static final Interpolator c = new android.support.v4.i.b.a();
    static final Interpolator d = new c();
    static final Interpolator e = new DecelerateInterpolator();
}
