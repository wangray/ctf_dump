package android.support.design.widget;

import android.graphics.drawable.Drawable;

interface k {
    float a();

    void a(int i, int i2, int i3, int i4);

    void a(Drawable drawable);

    boolean b();
}
