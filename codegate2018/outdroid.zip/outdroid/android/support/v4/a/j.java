package android.support.v4.a;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class j {
    public h a(Context context, String str, Bundle bundle) {
        return h.a(context, str, bundle);
    }

    public abstract View a(int i);

    public abstract boolean a();
}
