package android.support.v4.a;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class m {

    public static abstract class a {
        public void a(m mVar, h hVar) {
        }

        public void a(m mVar, h hVar, Context context) {
        }

        public void a(m mVar, h hVar, Bundle bundle) {
        }

        public void a(m mVar, h hVar, View view, Bundle bundle) {
        }

        public void b(m mVar, h hVar) {
        }

        public void b(m mVar, h hVar, Context context) {
        }

        public void b(m mVar, h hVar, Bundle bundle) {
        }

        public void c(m mVar, h hVar) {
        }

        public void c(m mVar, h hVar, Bundle bundle) {
        }

        public void d(m mVar, h hVar) {
        }

        public void d(m mVar, h hVar, Bundle bundle) {
        }

        public void e(m mVar, h hVar) {
        }

        public void f(m mVar, h hVar) {
        }

        public void g(m mVar, h hVar) {
        }
    }

    public interface b {
        void a();
    }

    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract boolean a();

    public abstract List<h> b();

    public abstract boolean c();
}
