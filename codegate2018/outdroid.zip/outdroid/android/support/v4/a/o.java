package android.support.v4.a;

import java.util.List;

public class o {
    private final List<h> a;
    private final List<o> b;

    o(List<h> list, List<o> list2) {
        this.a = list;
        this.b = list2;
    }

    List<h> a() {
        return this.a;
    }

    List<o> b() {
        return this.b;
    }
}
