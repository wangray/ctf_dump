package android.support.v4.i;

public interface i {
    boolean isNestedScrollingEnabled();

    void stopNestedScroll();
}
