package android.support.v4.i;

import android.view.View;

public interface o {
    x a(View view, x xVar);
}
