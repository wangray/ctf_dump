package android.support.v4.i;

import android.view.View;

public interface u {
    void a(View view);

    void b(View view);

    void c(View view);
}
