package android.support.v4.i;

import android.view.View;

public class v implements u {
    public void a(View view) {
    }

    public void b(View view) {
    }

    public void c(View view) {
    }
}
