package android.support.v4.i;

import android.view.View;

public interface w {
    void a(View view);
}
