package android.support.v7.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.Window;

class h extends k {
    h(Context context, Window window, d dVar) {
        super(context, window, dVar);
    }

    View a(View view, String str, Context context, AttributeSet attributeSet) {
        return null;
    }
}
