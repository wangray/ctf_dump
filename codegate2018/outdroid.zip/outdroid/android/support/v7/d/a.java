package android.support.v7.d;

import com.example.puing.a2018codegate.R;

public final class a {

    public static final class a {
        public static final int compat_button_inset_horizontal_material = 2131099722;
        public static final int compat_button_inset_vertical_material = 2131099723;
        public static final int compat_button_padding_horizontal_material = 2131099724;
        public static final int compat_button_padding_vertical_material = 2131099725;
        public static final int compat_control_corner_material = 2131099726;
        public static final int fastscroll_default_thickness = 2131099768;
        public static final int fastscroll_margin = 2131099769;
        public static final int fastscroll_minimum_range = 2131099770;
        public static final int item_touch_helper_max_drag_scroll_per_frame = 2131099778;
        public static final int item_touch_helper_swipe_escape_max_velocity = 2131099779;
        public static final int item_touch_helper_swipe_escape_velocity = 2131099780;
        public static final int notification_action_icon_size = 2131099781;
        public static final int notification_action_text_size = 2131099782;
        public static final int notification_big_circle_margin = 2131099783;
        public static final int notification_content_margin_start = 2131099784;
        public static final int notification_large_icon_height = 2131099785;
        public static final int notification_large_icon_width = 2131099786;
        public static final int notification_main_column_padding_top = 2131099787;
        public static final int notification_media_narrow_margin = 2131099788;
        public static final int notification_right_icon_size = 2131099789;
        public static final int notification_right_side_padding_top = 2131099790;
        public static final int notification_small_icon_background_padding = 2131099791;
        public static final int notification_small_icon_size_as_large = 2131099792;
        public static final int notification_subtext_size = 2131099793;
        public static final int notification_top_pad = 2131099794;
        public static final int notification_top_pad_large_text = 2131099795;
    }

    public static final class b {
        public static final int[] FontFamily = new int[]{R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = new int[]{R.attr.font, R.attr.fontStyle, R.attr.fontWeight};
        public static final int FontFamilyFont_font = 0;
        public static final int FontFamilyFont_fontStyle = 1;
        public static final int FontFamilyFont_fontWeight = 2;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] RecyclerView = new int[]{16842948, 16842993, R.attr.fastScrollEnabled, R.attr.fastScrollHorizontalThumbDrawable, R.attr.fastScrollHorizontalTrackDrawable, R.attr.fastScrollVerticalThumbDrawable, R.attr.fastScrollVerticalTrackDrawable, R.attr.layoutManager, R.attr.reverseLayout, R.attr.spanCount, R.attr.stackFromEnd};
        public static final int RecyclerView_android_descendantFocusability = 1;
        public static final int RecyclerView_android_orientation = 0;
        public static final int RecyclerView_fastScrollEnabled = 2;
        public static final int RecyclerView_fastScrollHorizontalThumbDrawable = 3;
        public static final int RecyclerView_fastScrollHorizontalTrackDrawable = 4;
        public static final int RecyclerView_fastScrollVerticalThumbDrawable = 5;
        public static final int RecyclerView_fastScrollVerticalTrackDrawable = 6;
        public static final int RecyclerView_layoutManager = 7;
        public static final int RecyclerView_reverseLayout = 8;
        public static final int RecyclerView_spanCount = 9;
        public static final int RecyclerView_stackFromEnd = 10;
    }
}
