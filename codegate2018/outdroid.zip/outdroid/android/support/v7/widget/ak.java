package android.support.v7.widget;

import android.graphics.Rect;

public interface ak {

    public interface a {
        void a(Rect rect);
    }

    void setOnFitSystemWindowsListener(a aVar);
}
