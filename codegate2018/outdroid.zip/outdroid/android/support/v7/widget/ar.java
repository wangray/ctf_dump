package android.support.v7.widget;

import android.support.v7.view.menu.h;
import android.view.MenuItem;

public interface ar {
    void a(h hVar, MenuItem menuItem);

    void b(h hVar, MenuItem menuItem);
}
