package android.support.v7.widget;

import android.content.res.Resources.Theme;
import android.widget.SpinnerAdapter;

public interface be extends SpinnerAdapter {
    Theme a();

    void a(Theme theme);
}
